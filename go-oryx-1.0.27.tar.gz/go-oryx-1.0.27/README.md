# go-oryx

![](http://ossrs.net:8000/gif/v1/sls.gif?site=github.com&path=/srs/gooryx)
[![](https://cloud.githubusercontent.com/assets/2777660/22814959/c51cbe72-ef92-11e6-81cc-32b657b285d5.png)](https://github.com/ossrs/srs/wiki/v1_CN_Contact#wechat)
[![](https://github.com/ossrs/go-oryx/actions/workflows/release.yml/badge.svg)](https://github.com/ossrs/go-oryx/actions/workflows/release.yml?query=workflow%3ARelease)

The oryx is a group of isolate processes:

1. `httpx-static` HTTP/HTTPS static server with API proxy.

Winlin 2016.07.09

