|name|demonstrates|
---|---
minimal-raw-adopt-tcp|Shows how to have lws adopt an existing tcp socket something else had connected
minimal-raw-adopt-udp|Shows how to create a udp socket and read and write on it
minimal-raw-fallback-http|Shows how to run a normal http(s) server that falls back to a specified role + protocol
minimal-raw-file|Shows how to adopt a file descriptor (device node, fifo, file, etc) into the lws event loop and handle events
minimal-raw-netcat|Writes stdin to a remote server and prints results on stdout
minimal-raw-proxy-fallback|Shows how to run a normal http(s) server that falls back to a proxied connection to a specified IP and port
minimal-raw-proxy|Shows how to set up a vhost so it listens for connections and proxies them to a specified IP and port
minimal-raw-vhost|Shows how to set up a vhost that listens and accepts RAW socket connections

