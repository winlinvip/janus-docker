|Example|Demonstrates|
---|---
minimal-ws-broker|Simple ws server with a publish / broker / subscribe architecture
minimal-ws-server-echo|Simple ws server that listens and echos back anything clients send
minimal-ws-server-pmd-bulk|Simple ws server showing how to pass bulk data with permessage-deflate
minimal-ws-server-pmd-corner|Corner-case tests for permessage-deflate
minimal-ws-server-pmd|Simple ws server with permessage-deflate support
minimal-ws-server-ring|Like minimal-ws-server but holds the chat in a multi-tail ringbuffer
minimal-ws-server-threadpool|Demonstrates how to use a worker thread pool with lws
minimal-ws-server-threads-smp|SMP ws server where data is produced by different threads with multiple lws service threads too
minimal-ws-server-threads|Simple ws server where data is produced by different threads
minimal-ws-server|Serves an index.html over http that opens a ws shared chat client in a browser

